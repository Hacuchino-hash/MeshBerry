#pragma once

#include <variant_generic.h>

#undef RNG
